class UserModelChoices:
    COLLECTION = "users"
    EMAIL_DOMAINS = ["gmail.com", "mslate.ai"]

    user = "User"
    admin = "Administrator"
    moderator = "Moderator"