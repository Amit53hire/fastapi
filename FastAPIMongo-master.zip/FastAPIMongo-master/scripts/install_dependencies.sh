pip-compile
python -m pip install -r requirements.txt