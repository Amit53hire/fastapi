class DatabaseCollections:
    users: str = "users"
    blacklisted_tokens :str = "blacklistedTokens"